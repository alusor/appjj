package com.sherdle.universal;

public interface PermissionsFragment {

    String[] requiredPermissions();

}
